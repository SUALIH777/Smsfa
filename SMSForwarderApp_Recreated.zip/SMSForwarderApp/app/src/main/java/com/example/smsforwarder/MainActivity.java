
package com.example.smsforwarder;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText phoneNumberInput = findViewById(R.id.phone_number_input);
        Button saveButton = findViewById(R.id.save_button);

        SharedPreferences preferences = getSharedPreferences("sms_forwarder", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        // Load existing forwarding number
        phoneNumberInput.setText(preferences.getString("forwarding_number", "+251942619845"));

        // Save forwarding number on button click
        saveButton.setOnClickListener(v -> {
            String newNumber = phoneNumberInput.getText().toString();
            editor.putString("forwarding_number", newNumber);
            editor.apply();
        });
    }
}
